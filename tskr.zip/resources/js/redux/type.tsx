export const BRESH_TIME=[
    "3分未満",
    "3-5分",
    "5-10分",
    "10分以上"
];
export const BRESH_TOOL=[
    "歯間ブラシ",
    "洗口材",
    "フロス・糸ようじ"
]
export const MO_STATUS=[
    '問題ない',
    '口が乾く',
    'ネバネバする',
    '血の味がする',
    '顎が疲れている',
    'その他の問題がある'
]
export const PROGRAM=[
    "プログラムA",
    "プログラムB",
    "プログラムC",
    "プログラムD"
]
export const SELF=[
    "陽性",
    "陰性",
    "わからない"
]
export const LINELOGIN='https://access.line.me/oauth2/v2.1/authorize?response_type=code&client_id=1657281804&redirect_uri=http://tmdu-crpe22.jp/linelogin&state='
