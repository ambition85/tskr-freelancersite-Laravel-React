commnad.
First you should install xamp or php \n
In cmd, run command:php artisan serve \n
In Chrome,url:http://localhost:8000/    \n
You will show my design